/* *****************************************************************************
 *  Name:              Siarhei Muliarenka
 *  Coursera User ID:  123456
 *  Last modified:     March 6, 2022
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    // states of the grid's site:
    // false - blocked, true - open (full or not), 2 - full
    private boolean[][] grid;
    private int gridSize;
    private int openSites = 0;

    private WeightedQuickUnionUF uF;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0)
            throw new IllegalArgumentException();
        gridSize = n;
        grid = new boolean[gridSize][gridSize];
        for (int i = 0; i < gridSize; i++)
            for (int j = 0; j < gridSize; j++)
                grid[i][j] = false;
        initUF(gridSize);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row < 1 || row > gridSize || col < 1 || col > gridSize)
            throw new IllegalArgumentException();
        if (!isOpen(row, col)) {
            grid[row - 1][col - 1] = true;
            openSites++;
            lookAroundForFull(row, col);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row < 1 || row > gridSize || col < 1 || col > gridSize)
            throw new IllegalArgumentException();
        return grid[row - 1][col - 1];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row < 1 || row > gridSize || col < 1 || col > gridSize)
            throw new IllegalArgumentException();
        return uF.find(getUfIndex(row, col)) == uF.find(0);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return uF.find(0) == uF.find(gridSize + gridSize * gridSize);
    }

    // test client (optional)
    public static void main(String[] args) {

    }

    private void initUF(int size) {
        uF = new WeightedQuickUnionUF(size * (2 + size));
        for (int i = 1; i < size; i++) {
            // virtual row above the top row of grid
            uF.union(0, i);
            // virtual row under the bottom row of grid
            uF.union(size + size * size, size + size * size + i);
        }
    }

    // returns corresponding index from a grid's row and col
    private int getUfIndex(int row, int col) {
        return gridSize * row + col - 1;
    }

    // looks for a full unit
    private void lookAroundForFull(int row, int col) {
        // top unit's index
        if (row > 1 && isFull(row - 1, col)) {
            uF.union(0, getUfIndex(row, col));
        }
        // left unit's index
        if (col > 1 && isFull(row, col - 1)) {
            uF.union(0, getUfIndex(row, col));
        }
        // right unit's index
        if (col < gridSize && isFull(row, col + 1)) {
            uF.union(0, getUfIndex(row, col));
        }
        // bottom unit's index
        if (row < gridSize && isFull(row + 1, col)) {
            uF.union(0, getUfIndex(row, col));
        }
        // look around for open unit, but don`t full
        if (isFull(row, col)) {
            // top unit's index
            if (row > 1 && !isFull(row - 1, col) && isOpen(row - 1, col)) {
                lookAroundForFull(row - 1, col);
            }
            // left unit's index
            if (col > 1 && !isFull(row, col - 1) && isOpen(row, col - 1)) {
                lookAroundForFull(row, col - 1);
            }
            // right unit's index
            if (col < gridSize && !isFull(row, col + 1) && isOpen(row, col + 1)) {
                lookAroundForFull(row, col + 1);
            }
            // bottom unit's index
            if (row < gridSize && !isFull(row + 1, col) && isOpen(row + 1, col)) {
                lookAroundForFull(row + 1, col);
            }
        }
    }
}
